import{c as d,u as l,a as y,j as t,F as j,C as m}from"./index-BvLFKeDu.js";import"./vendor-xterm-COrdvm1H.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=d("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=d("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=d("FilePlus",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M9 15h6",key:"cctwl0"}],["path",{d:"M12 18v-6",key:"17g6i2"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=d("FileX",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m14.5 12.5-5 5",key:"b62r18"}],["path",{d:"m9.5 12.5 5 5",key:"1rk7el"}]]);function w(){const s=l(e=>e.changeSets),c=l(e=>e.activeChangeSetId),o=l(e=>e.setActiveChangeSet),x=l(e=>e.acceptAllInFile),p=l(e=>e.rejectAllInFile),h=y(e=>e.addEditorTab),r=Object.values(s),n=r.reduce((e,a)=>e+Object.values(a.files).filter(i=>i.status==="pending").length,0),g=(e,a)=>{o(e.id),h({id:a.id,filePath:a.filePath,label:a.filePath.split("/").pop()||a.filePath,icon:a.oldContent===null?"add":a.newContent===null?"delete":"modify",changeSetId:e.id})};return t.jsxs("div",{className:"flex flex-col h-full",children:[t.jsxs("div",{className:"flex items-center justify-between px-3 py-3 border-b border-border",children:[t.jsx("span",{className:"text-xs font-semibold text-text-secondary uppercase tracking-wider",children:"Code Changes"}),n>0&&t.jsxs("span",{className:"text-[10px] px-1.5 py-0.5 rounded bg-accent/20 text-accent font-medium",children:[n," pending"]})]}),t.jsxs("div",{className:"flex-1 overflow-y-auto",children:[r.length===0&&t.jsxs("div",{className:"p-4 text-center",children:[t.jsx("p",{className:"text-xs text-text-secondary italic",children:"No code changes detected."}),t.jsx("p",{className:"text-xs text-text-secondary mt-1 opacity-70",children:"Changes from CLI sessions will appear here."})]}),r.map(e=>t.jsxs("div",{className:"border-b border-border last:border-b-0",children:[t.jsxs("div",{onClick:()=>o(e.id===c?null:e.id),className:`
                px-3 py-2 flex items-center gap-2 cursor-pointer transition-colors
                ${e.id===c?"bg-accent/10":"hover:bg-bg-tertiary"}
              `,children:[t.jsx("span",{className:`w-1.5 h-1.5 rounded-full flex-shrink-0 ${e.status==="complete"?"bg-green-400":"bg-yellow-400"}`}),t.jsx("span",{className:"text-xs text-text-primary truncate flex-1",children:e.description||`Change Set ${e.id.slice(0,8)}`}),t.jsxs("span",{className:"text-[10px] text-text-secondary",children:[Object.keys(e.files).length," files"]})]}),e.id===c&&t.jsx("div",{className:"border-t border-border/50",children:Object.entries(e.files).map(([a,i])=>t.jsx(C,{file:i,onClick:()=>g(e,i),onAccept:()=>x(e.id,a),onReject:()=>p(e.id,a)},i.id))})]},e.id))]})]})}function C({file:s,onClick:c,onAccept:o,onReject:x}){const p=s.oldContent===null?t.jsx(k,{size:14,className:"text-green-400 flex-shrink-0"}):s.newContent===null?t.jsx(v,{size:14,className:"text-red-400 flex-shrink-0"}):t.jsx(j,{size:14,className:"text-yellow-400 flex-shrink-0"}),h=s.status==="accepted"?t.jsx(m,{size:12,className:"text-green-400 flex-shrink-0"}):s.status==="rejected"?t.jsx(u,{size:12,className:"text-red-400 flex-shrink-0"}):t.jsx(b,{size:12,className:"text-text-secondary flex-shrink-0"}),r=s.filePath.split("/").pop()||s.filePath;return t.jsxs("div",{className:`
        group px-3 py-1.5 flex items-center gap-2 cursor-pointer transition-colors
        hover:bg-bg-tertiary
        ${s.status==="accepted"?"opacity-60":""}
        ${s.status==="rejected"?"opacity-50":""}
      `,children:[t.jsxs("div",{onClick:c,className:"flex items-center gap-2 flex-1 min-w-0",children:[p,t.jsx("span",{className:"text-xs text-text-primary truncate",children:r}),t.jsx("span",{className:"text-[10px] text-text-secondary truncate opacity-70 hidden group-hover:inline",children:s.filePath})]}),s.status==="pending"&&t.jsxs("div",{className:"flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity",children:[t.jsx("button",{onClick:n=>{n.stopPropagation(),x()},className:"p-0.5 hover:bg-red-900/30 rounded text-red-400",title:"Reject",children:t.jsx(u,{size:14})}),t.jsx("button",{onClick:n=>{n.stopPropagation(),o()},className:"p-0.5 hover:bg-green-900/30 rounded text-green-400",title:"Accept",children:t.jsx(m,{size:14})})]}),s.status!=="pending"&&h]})}export{w as CodeChangesSidebar};
